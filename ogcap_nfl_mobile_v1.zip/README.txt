OGCAP NFL SIM LAB — Mobile V1

This is a standalone experimental dashboard. No internet required after loading. It uses manual team scoring inputs and a simplified normal scoring model; no live data, calibrated team ratings, overtime, or player props yet.

To put it on your iPhone as a normal website: publish index.html using a free static hosting service such as GitHub Pages, then open the resulting HTTPS URL in Safari and choose Share > Add to Home Screen. Hosting requires your own account and setup. Alternatively, open index.html in a desktop browser to test immediately.

Do not use prototype results as verified betting edges.
